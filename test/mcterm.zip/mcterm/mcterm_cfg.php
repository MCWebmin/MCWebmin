<?php
/***** CONFIG OPTIONS *****/

//number of seconds to allow for a command to respond
$response_delay = 1;
//number of seconds to wait when polling for msgs 
//(Has to be less than your PHP script timeout)
$poll_timer = 1;
//command port for mineremote
$port  = 9001;
//server hosting mineremote
$server = "127.0.0.1";

/***** END CONFIG *****/
?>